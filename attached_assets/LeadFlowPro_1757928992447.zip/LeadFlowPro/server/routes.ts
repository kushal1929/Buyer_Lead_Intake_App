import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertLeadSchema } from "@shared/schema";
import { z } from "zod";

const leadQuerySchema = z.object({
  search: z.string().optional(),
  propertyType: z.enum(["residential", "commercial", "land"]).optional(),
  status: z.enum(["active", "follow_up", "converted", "inactive"]).optional(),
  page: z.string().transform(Number).default("1"),
  limit: z.string().transform(Number).default("10"),
});

export function registerRoutes(app: Express): Server {
  setupAuth(app);

  // Get leads with filtering and pagination
  app.get("/api/leads", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const query = leadQuerySchema.parse(req.query);
      const leads = await storage.getLeads(req.user!.id, query);
      const total = await storage.getLeadsCount(req.user!.id, query);
      
      res.json({
        leads,
        total,
        page: query.page,
        limit: query.limit,
        totalPages: Math.ceil(total / query.limit),
      });
    } catch (error) {
      res.status(400).json({ error: "Invalid query parameters" });
    }
  });

  // Get lead by id
  app.get("/api/leads/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const lead = await storage.getLead(req.params.id);
    if (!lead || lead.userId !== req.user!.id) {
      return res.status(404).json({ error: "Lead not found" });
    }
    
    res.json(lead);
  });

  // Create lead
  app.post("/api/leads", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const leadData = insertLeadSchema.parse(req.body);
      const lead = await storage.createLead({
        ...leadData,
        userId: req.user!.id,
      });
      res.status(201).json(lead);
    } catch (error) {
      res.status(400).json({ error: "Invalid lead data" });
    }
  });

  // Update lead
  app.put("/api/leads/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const existingLead = await storage.getLead(req.params.id);
    if (!existingLead || existingLead.userId !== req.user!.id) {
      return res.status(404).json({ error: "Lead not found" });
    }
    
    try {
      const leadData = insertLeadSchema.parse(req.body);
      const lead = await storage.updateLead(req.params.id, leadData);
      res.json(lead);
    } catch (error) {
      res.status(400).json({ error: "Invalid lead data" });
    }
  });

  // Delete lead
  app.delete("/api/leads/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const existingLead = await storage.getLead(req.params.id);
    if (!existingLead || existingLead.userId !== req.user!.id) {
      return res.status(404).json({ error: "Lead not found" });
    }
    
    await storage.deleteLead(req.params.id);
    res.sendStatus(204);
  });

  // Get dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const stats = await storage.getDashboardStats(req.user!.id);
    res.json(stats);
  });

  // Import CSV
  app.post("/api/leads/import", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const { leads: csvLeads } = req.body;
      const results = await storage.importLeads(req.user!.id, csvLeads);
      res.json(results);
    } catch (error) {
      res.status(400).json({ error: "Import failed" });
    }
  });

  // Export CSV
  app.get("/api/leads/export", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const query = leadQuerySchema.parse(req.query);
      const csv = await storage.exportLeads(req.user!.id, query);
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename="leads.csv"');
      res.send(csv);
    } catch (error) {
      res.status(400).json({ error: "Export failed" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
