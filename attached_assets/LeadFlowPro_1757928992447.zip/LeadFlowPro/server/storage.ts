import { type User, type InsertUser, type Lead, type InsertLead, users, leads } from "@shared/schema";
import { randomUUID } from "crypto";
import session from "express-session";
import createMemoryStore from "memorystore";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";
import { drizzle } from "drizzle-orm/postgres-js";
import { eq, and, ilike, or, desc, gte, sql } from "drizzle-orm";
import postgres from "postgres";
import ConnectPgSimple from "connect-pg-simple";

const MemoryStore = createMemoryStore(session);
const PgSession = ConnectPgSimple(session);
const scryptAsync = promisify(scrypt);

// Database connection
const connectionString = process.env.DATABASE_URL!;
const client = postgres(connectionString);
export const db = drizzle(client);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

export interface LeadQuery {
  search?: string;
  propertyType?: "residential" | "commercial" | "land";
  status?: "active" | "follow_up" | "converted" | "inactive";
  page: number;
  limit: number;
}

export interface DashboardStats {
  totalLeads: number;
  activeLeads: number;
  convertedLeads: number;
  monthlyLeads: number;
}

export interface ImportResult {
  total: number;
  successful: number;
  errors: Array<{ row: number; message: string }>;
}

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getLeads(userId: string, query: LeadQuery): Promise<Lead[]>;
  getLeadsCount(userId: string, query: Omit<LeadQuery, 'page' | 'limit'>): Promise<number>;
  getLead(id: string): Promise<Lead | undefined>;
  createLead(lead: InsertLead & { userId: string }): Promise<Lead>;
  updateLead(id: string, lead: Partial<InsertLead>): Promise<Lead>;
  deleteLead(id: string): Promise<void>;
  
  getDashboardStats(userId: string): Promise<DashboardStats>;
  importLeads(userId: string, leads: InsertLead[]): Promise<ImportResult>;
  exportLeads(userId: string, query: Omit<LeadQuery, 'page' | 'limit'>): Promise<string>;
  
  sessionStore: session.Store;
}

export class DbStorage implements IStorage {
  public sessionStore: session.Store;

  constructor() {
    // Use PostgreSQL session store for production
    if (process.env.DATABASE_URL) {
      this.sessionStore = new PgSession({
        conString: process.env.DATABASE_URL,
        tableName: 'session',
        createTableIfMissing: true,
      });
    } else {
      this.sessionStore = new MemoryStore({
        checkPeriod: 86400000,
      });
    }
    
    // Initialize with demo user if needed
    this.initializeDemoUser();
  }

  private async initializeDemoUser() {
    try {
      // Check if demo user already exists
      const existingUser = await this.getUserByUsername("demo");
      if (existingUser) return;
      
      const hashedPassword = await hashPassword("demo123");
      
      const demoUser = await db.insert(users).values({
        username: "demo",
        email: "demo@example.com", 
        password: hashedPassword,
      }).returning();
      
      const demoUserId = demoUser[0].id;

      // Add some sample leads for demo user
      const sampleLeads = [
        {
          userId: demoUserId,
          firstName: "John",
          lastName: "Smith",
          email: "john.smith@example.com",
          phone: "+1234567890",
          propertyType: "residential" as const,
          bhk: "3",
          minBudget: "400000",
          maxBudget: "500000",
          preferredLocation: "Downtown",
          notes: "Looking for a family home with good schools nearby",
          status: "active" as const,
        },
        {
          userId: demoUserId,
          firstName: "Maria",
          lastName: "Johnson",
          email: "maria.j@example.com",
          phone: "+1987654321",
          propertyType: "commercial" as const,
          minBudget: "1000000",
          maxBudget: "1500000",
          preferredLocation: "Business District",
          notes: "Interested in office space for tech startup",
          status: "follow_up" as const,
        },
        {
          userId: demoUserId,
          firstName: "David",
          lastName: "Wilson",
          email: "d.wilson@example.com",
          phone: "+1555666777",
          propertyType: "residential" as const,
          bhk: "2",
          minBudget: "300000",
          maxBudget: "400000",
          preferredLocation: "Suburbs",
          notes: "First-time buyer, flexible on timeline",
          status: "converted" as const,
        },
        {
          userId: demoUserId,
          firstName: "Sarah",
          lastName: "Brown",
          email: "sarah.brown@example.com",
          phone: "+1444555666",
          propertyType: "land" as const,
          minBudget: "200000",
          maxBudget: "300000",
          preferredLocation: "Outskirts",
          notes: "Looking for land to build custom home",
          status: "active" as const,
        },
      ];

      // Insert sample leads
      for (const leadData of sampleLeads) {
        await db.insert(leads).values(leadData);
      }
    } catch (error) {
      // Ignore errors during demo user initialization
      console.log("Demo user initialization skipped:", error);
    }
  }

  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  private buildLeadQuery(userId: string, query: Omit<LeadQuery, 'page' | 'limit'>) {
    let whereConditions: any[] = [eq(leads.userId, userId)];
    
    if (query.search) {
      const searchTerm = `%${query.search.toLowerCase()}%`;
      whereConditions.push(
        or(
          ilike(leads.firstName, searchTerm),
          ilike(leads.lastName, searchTerm),
          ilike(leads.email, searchTerm),
          ilike(leads.preferredLocation, searchTerm)
        )
      );
    }
    
    if (query.propertyType) {
      whereConditions.push(eq(leads.propertyType, query.propertyType));
    }
    
    if (query.status) {
      whereConditions.push(eq(leads.status, query.status));
    }
    
    return and(...whereConditions);
  }

  async getLeads(userId: string, query: LeadQuery): Promise<Lead[]> {
    const whereCondition = this.buildLeadQuery(userId, query);
    const offset = (query.page - 1) * query.limit;
    
    const result = await db.select().from(leads)
      .where(whereCondition)
      .orderBy(desc(leads.createdAt))
      .limit(query.limit)
      .offset(offset);
    
    return result;
  }

  async getLeadsCount(userId: string, query: Omit<LeadQuery, 'page' | 'limit'>): Promise<number> {
    const whereCondition = this.buildLeadQuery(userId, query);
    const result = await db.select({ count: sql`count(*)` }).from(leads).where(whereCondition);
    return Number(result[0].count);
  }

  async getLead(id: string): Promise<Lead | undefined> {
    const result = await db.select().from(leads).where(eq(leads.id, id)).limit(1);
    return result[0];
  }

  async createLead(leadData: InsertLead & { userId: string }): Promise<Lead> {
    const insertData = {
      ...leadData,
      status: leadData.status || "active" as const,
    };
    const result = await db.insert(leads).values(insertData).returning();
    return result[0];
  }

  async updateLead(id: string, updates: Partial<InsertLead>): Promise<Lead> {
    const result = await db.update(leads)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(leads.id, id))
      .returning();
    
    if (result.length === 0) {
      throw new Error("Lead not found");
    }
    
    return result[0];
  }

  async deleteLead(id: string): Promise<void> {
    await db.delete(leads).where(eq(leads.id, id));
  }

  async getDashboardStats(userId: string): Promise<DashboardStats> {
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    
    const [totalResult, activeResult, convertedResult, monthlyResult] = await Promise.all([
      db.select({ count: sql`count(*)` }).from(leads).where(eq(leads.userId, userId)),
      db.select({ count: sql`count(*)` }).from(leads).where(and(eq(leads.userId, userId), eq(leads.status, "active"))),
      db.select({ count: sql`count(*)` }).from(leads).where(and(eq(leads.userId, userId), eq(leads.status, "converted"))),
      db.select({ count: sql`count(*)` }).from(leads).where(and(eq(leads.userId, userId), gte(leads.createdAt, monthStart)))
    ]);
    
    return {
      totalLeads: Number(totalResult[0].count),
      activeLeads: Number(activeResult[0].count),
      convertedLeads: Number(convertedResult[0].count),
      monthlyLeads: Number(monthlyResult[0].count),
    };
  }

  async importLeads(userId: string, leadsData: InsertLead[]): Promise<ImportResult> {
    const result: ImportResult = {
      total: leadsData.length,
      successful: 0,
      errors: [],
    };

    for (let i = 0; i < leadsData.length; i++) {
      try {
        // Validate required fields
        const leadData = leadsData[i];
        if (!leadData.firstName || !leadData.lastName || !leadData.email || !leadData.propertyType) {
          throw new Error("Missing required fields: firstName, lastName, email, propertyType");
        }

        // Validate property type
        if (!["residential", "commercial", "land"].includes(leadData.propertyType)) {
          throw new Error("Invalid property type. Must be: residential, commercial, or land");
        }

        // Validate status if provided
        if (leadData.status && !["active", "follow_up", "converted", "inactive"].includes(leadData.status)) {
          throw new Error("Invalid status. Must be: active, follow_up, converted, or inactive");
        }

        await this.createLead({ ...leadData, userId });
        result.successful++;
      } catch (error) {
        result.errors.push({
          row: i + 1,
          message: error instanceof Error ? error.message : "Unknown error",
        });
      }
    }

    return result;
  }

  async exportLeads(userId: string, query: Omit<LeadQuery, 'page' | 'limit'>): Promise<string> {
    const whereCondition = this.buildLeadQuery(userId, query);
    const leadsData = await db.select().from(leads)
      .where(whereCondition)
      .orderBy(desc(leads.createdAt));
    
    const headers = [
      "First Name", "Last Name", "Email", "Phone", "Property Type", 
      "BHK", "Min Budget", "Max Budget", "Preferred Location", "Notes", "Status", "Created At"
    ];
    
    const rows = leadsData.map(lead => [
      lead.firstName,
      lead.lastName,
      lead.email,
      lead.phone || "",
      lead.propertyType,
      lead.bhk || "",
      lead.minBudget || "",
      lead.maxBudget || "",
      lead.preferredLocation || "",
      lead.notes || "",
      lead.status,
      lead.createdAt.toISOString(),
    ]);
    
    const csvContent = [headers, ...rows]
      .map(row => row.map(field => `"${field}"`).join(","))
      .join("\n");
    
    return csvContent;
  }
}

export const storage = new DbStorage();
