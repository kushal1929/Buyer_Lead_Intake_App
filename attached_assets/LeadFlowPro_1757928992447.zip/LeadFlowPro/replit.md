# Overview

This is a comprehensive real estate buyer lead management application (CRM) built with React, TypeScript, and Express.js. The application provides a complete solution for real estate professionals to manage buyer leads with features like user authentication, lead CRUD operations, advanced filtering, CSV import/export capabilities, and a responsive dashboard interface.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The frontend uses a modern React-based Single Page Application (SPA) architecture:
- **React 18** with TypeScript for type safety and modern React features
- **Vite** as the build tool for fast development and optimized production builds
- **Wouter** for lightweight client-side routing instead of React Router
- **TanStack Query** for server state management, caching, and data fetching
- **React Hook Form** with Zod validation for form handling and validation
- **Tailwind CSS** with **Shadcn/ui** component library for consistent, responsive UI design
- Component-based architecture with reusable UI components organized under `/client/src/components/ui/`

## Backend Architecture
The backend follows a traditional Express.js server architecture:
- **Express.js** with TypeScript for the REST API server
- **Passport.js** with Local Strategy for authentication using username/password
- **Express Session** for session-based authentication management
- Session store can be configured for either in-memory (MemoryStore) or PostgreSQL (PgSession)
- **Zod** schemas for runtime validation on both client and server sides
- RESTful API design with proper HTTP status codes and error handling

## Database Architecture
The application uses **Drizzle ORM** with PostgreSQL for data persistence:
- Type-safe database queries and migrations
- Schema definitions in `/shared/schema.ts` shared between client and server
- Two main entities: `users` and `leads`
- PostgreSQL enums for property types (residential, commercial, land) and lead statuses
- Database connection through `@neondatabase/serverless` for cloud deployment compatibility

## Authentication & Authorization
- Session-based authentication using Express Session
- Password hashing with Node.js built-in `scrypt` for security
- User ownership model where users can only access their own leads
- Protected routes on both frontend and backend
- Authentication context provider for React components

## State Management
- **TanStack Query** for server state (API data, caching, background updates)
- React Context for authentication state management
- Local React state for UI-specific state (modals, forms, filters)
- Form state managed by React Hook Form with Zod validation

## API Design
RESTful API structure:
- `/api/leads` - CRUD operations for leads with filtering and pagination
- `/api/auth` - Authentication endpoints (login, logout, register)
- `/api/dashboard/stats` - Dashboard statistics
- `/api/leads/import` - Bulk CSV import functionality
- `/api/leads/export` - CSV export with filtering

## Data Validation
Shared validation schemas using Zod:
- Runtime validation on both client and server
- Type safety with TypeScript integration
- Consistent validation rules across the application
- Form validation with real-time feedback

# External Dependencies

## Database Services
- **PostgreSQL** - Primary database for data storage
- **Neon Database** - Cloud PostgreSQL provider (via @neondatabase/serverless)
- **Drizzle ORM** - Type-safe database toolkit and query builder

## Authentication & Security
- **Passport.js** - Authentication middleware for Node.js
- **Express Session** - Session management middleware
- **connect-pg-simple** - PostgreSQL session store for Express Session

## UI & Styling
- **Tailwind CSS** - Utility-first CSS framework
- **Shadcn/ui** - Component library built on Radix UI primitives
- **Radix UI** - Unstyled, accessible UI primitives
- **Lucide React** - Icon library for React

## Development Tools
- **TypeScript** - Static type checking
- **Vite** - Build tool and development server
- **ESLint** & **Prettier** - Code quality and formatting
- **PostCSS** - CSS processing

## Data Processing
- **Papa Parse** - CSV parsing library for import/export functionality
- **date-fns** - Date utility library for formatting and manipulation

## Runtime & Deployment
- **Node.js** - JavaScript runtime environment
- **Express.js** - Web application framework
- **tsx** - TypeScript execution for development
- **esbuild** - JavaScript bundler for production builds