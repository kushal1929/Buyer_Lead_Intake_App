# Buyer Lead Intake - Real Estate CRM

A comprehensive real estate buyer lead management application built with React, TypeScript, and Express.

## Features

- **User Authentication**: Secure login and registration system with session management
- **Lead Management**: Complete CRUD operations for buyer leads
- **Advanced Search & Filtering**: Filter leads by property type, status, and search across multiple fields
- **Conditional Fields**: Dynamic form fields (BHK for residential properties)
- **CSV Import/Export**: Bulk import leads from CSV files and export filtered data
- **User Ownership**: Users can only access their own leads
- **Responsive Design**: Mobile-friendly interface with dark mode support
- **Real-time Validation**: Client and server-side validation using Zod schemas

## Tech Stack

### Frontend
- **React 18** with TypeScript
- **Tailwind CSS** for styling
- **Shadcn/ui** component library
- **React Hook Form** with Zod validation
- **TanStack Query** for data fetching
- **Wouter** for routing
- **Lucide React** for icons

### Backend
- **Express.js** with TypeScript
- **Passport.js** for authentication
- **Express Session** for session management
- **Zod** for runtime validation
- **In-memory storage** for demonstration

### Development Tools
- **Vite** for build tooling
- **ESLint** and **Prettier** for code quality
- **TypeScript** in strict mode

## Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd buyer-lead-intake
