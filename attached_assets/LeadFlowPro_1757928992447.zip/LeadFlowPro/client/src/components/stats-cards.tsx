import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Users, TrendingUp, Handshake, Calendar } from "lucide-react";

interface DashboardStats {
  totalLeads: number;
  activeLeads: number;
  convertedLeads: number;
  monthlyLeads: number;
}

export function StatsCards() {
  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  const cards = [
    {
      title: "Total Leads",
      value: stats?.totalLeads || 0,
      icon: Users,
      color: "blue",
      testId: "stat-total-leads",
    },
    {
      title: "Active Leads",
      value: stats?.activeLeads || 0,
      icon: TrendingUp,
      color: "green",
      testId: "stat-active-leads",
    },
    {
      title: "Converted",
      value: stats?.convertedLeads || 0,
      icon: Handshake,
      color: "purple",
      testId: "stat-converted-leads",
    },
    {
      title: "This Month",
      value: stats?.monthlyLeads || 0,
      icon: Calendar,
      color: "orange",
      testId: "stat-monthly-leads",
    },
  ];

  const getColorClasses = (color: string) => {
    switch (color) {
      case "blue": return "bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400";
      case "green": return "bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-400";
      case "purple": return "bg-purple-100 dark:bg-purple-900 text-purple-600 dark:text-purple-400";
      case "orange": return "bg-orange-100 dark:bg-orange-900 text-orange-600 dark:text-orange-400";
      default: return "bg-gray-100 dark:bg-gray-900 text-gray-600 dark:text-gray-400";
    }
  };

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardContent className="p-6">
              <div className="animate-pulse">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="h-4 bg-muted rounded w-20 mb-2"></div>
                    <div className="h-8 bg-muted rounded w-12"></div>
                  </div>
                  <div className="w-12 h-12 bg-muted rounded-lg"></div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6" data-testid="stats-cards">
      {cards.map((card) => {
        const Icon = card.icon;
        return (
          <Card key={card.title}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">{card.title}</p>
                  <p className="text-2xl font-bold text-card-foreground" data-testid={card.testId}>
                    {card.value}
                  </p>
                </div>
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${getColorClasses(card.color)}`}>
                  <Icon className="h-6 w-6" />
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                <span className="text-green-600">Updated</span> just now
              </p>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
