import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/sidebar";
import { StatsCards } from "@/components/stats-cards";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useState } from "react";
import { LeadFormModal } from "@/components/lead-form-modal";
import { Search, Plus, Edit, Trash2, Users, TrendingUp, Handshake, Calendar } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import type { Lead } from "@shared/schema";

interface LeadsResponse {
  leads: Lead[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export default function HomePage() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const { data: leadsData, isLoading } = useQuery<LeadsResponse>({
    queryKey: ["/api/leads", { search: searchQuery, limit: 10 }],
  });

  const recentLeads = leadsData?.leads || [];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active": return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100";
      case "follow_up": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100";
      case "converted": return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100";
      case "inactive": return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-100";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-100";
    }
  };

  const getPropertyTypeColor = (type: string) => {
    switch (type) {
      case "residential": return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100";
      case "commercial": return "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-100";
      case "land": return "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-100";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-100";
    }
  };

  const formatBudget = (min?: string, max?: string) => {
    if (!min && !max) return "Not specified";
    if (min && max) return `$${Number(min).toLocaleString()} - $${Number(max).toLocaleString()}`;
    if (min) return `From $${Number(min).toLocaleString()}`;
    if (max) return `Up to $${Number(max).toLocaleString()}`;
    return "Not specified";
  };

  return (
    <div className="min-h-screen bg-background flex">
      <Sidebar />
      
      <div className="flex-1 ml-64">
        {/* Header */}
        <header className="bg-card border-b border-border px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-semibold text-card-foreground" data-testid="page-title">
                Dashboard
              </h1>
              <p className="text-sm text-muted-foreground">Overview of your buyer leads</p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Input 
                  placeholder="Search leads..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-64 pl-10"
                  data-testid="search-input"
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              </div>
              <Button onClick={() => setIsModalOpen(true)} data-testid="button-add-lead">
                <Plus className="mr-2 h-4 w-4" />
                Add Lead
              </Button>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="p-6 space-y-6">
          <StatsCards />
          
          {/* Recent Leads Table */}
          <Card>
            <CardHeader>
              <CardTitle data-testid="recent-leads-title">Recent Leads</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                </div>
              ) : recentLeads.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground" data-testid="no-leads-message">
                  No leads found. Create your first lead to get started.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full" data-testid="leads-table">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Name</th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Email</th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Property Type</th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Budget</th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Status</th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Created</th>
                        <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {recentLeads.map((lead: Lead) => (
                        <tr key={lead.id} className="border-b border-border hover:bg-accent/50 transition-colors" data-testid={`lead-row-${lead.id}`}>
                          <td className="py-4 px-4">
                            <div className="flex items-center">
                              <Avatar className="h-8 w-8 mr-3">
                                <AvatarFallback className="text-xs">
                                  {lead.firstName[0]}{lead.lastName[0]}
                                </AvatarFallback>
                              </Avatar>
                              <span className="font-medium text-card-foreground" data-testid={`lead-name-${lead.id}`}>
                                {lead.firstName} {lead.lastName}
                              </span>
                            </div>
                          </td>
                          <td className="py-4 px-4 text-muted-foreground" data-testid={`lead-email-${lead.id}`}>
                            {lead.email}
                          </td>
                          <td className="py-4 px-4">
                            <Badge className={getPropertyTypeColor(lead.propertyType)} data-testid={`lead-property-type-${lead.id}`}>
                              {lead.propertyType}
                            </Badge>
                          </td>
                          <td className="py-4 px-4 text-card-foreground font-medium" data-testid={`lead-budget-${lead.id}`}>
                            {formatBudget(lead.minBudget || undefined, lead.maxBudget || undefined)}
                          </td>
                          <td className="py-4 px-4">
                            <Badge className={getStatusColor(lead.status)} data-testid={`lead-status-${lead.id}`}>
                              {lead.status.replace('_', ' ')}
                            </Badge>
                          </td>
                          <td className="py-4 px-4 text-muted-foreground" data-testid={`lead-created-${lead.id}`}>
                            {formatDistanceToNow(new Date(lead.createdAt), { addSuffix: true })}
                          </td>
                          <td className="py-4 px-4 text-right">
                            <div className="flex items-center justify-end space-x-2">
                              <Button size="sm" variant="ghost" data-testid={`button-edit-${lead.id}`}>
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button size="sm" variant="ghost" data-testid={`button-delete-${lead.id}`}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {!isLoading && recentLeads.length > 0 && (
                <div className="flex items-center justify-between mt-6 pt-4 border-t border-border">
                  <p className="text-sm text-muted-foreground" data-testid="table-pagination-info">
                    Showing {recentLeads.length} of {leadsData?.total || 0} leads
                  </p>
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm" disabled data-testid="button-previous">
                      Previous
                    </Button>
                    <Button size="sm" data-testid="button-page-1">1</Button>
                    <Button variant="outline" size="sm" disabled data-testid="button-next">
                      Next
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </main>
      </div>

      <LeadFormModal 
        open={isModalOpen} 
        onOpenChange={setIsModalOpen} 
      />
    </div>
  );
}
