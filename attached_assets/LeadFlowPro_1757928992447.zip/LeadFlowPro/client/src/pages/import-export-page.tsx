import { useState, useRef } from "react";
import { useMutation } from "@tanstack/react-query";
import { Sidebar } from "@/components/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Upload, Download, FileText, AlertCircle, CheckCircle } from "lucide-react";
import Papa from "papaparse";

interface ImportResult {
  total: number;
  successful: number;
  errors: Array<{ row: number; message: string }>;
}

export default function ImportExportPage() {
  const [dateRange, setDateRange] = useState("all");
  const [statusFilter, setStatusFilter] = useState("");
  const [propertyTypeFilter, setPropertyTypeFilter] = useState("");
  const [importResults, setImportResults] = useState<ImportResult | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const importMutation = useMutation({
    mutationFn: async (leads: any[]) => {
      const res = await apiRequest("POST", "/api/leads/import", { leads });
      return await res.json();
    },
    onSuccess: (result: ImportResult) => {
      setImportResults(result);
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Import completed",
        description: `${result.successful} leads imported successfully.`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Import failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const exportMutation = useMutation({
    mutationFn: async () => {
      const params = new URLSearchParams();
      if (statusFilter) params.append("status", statusFilter);
      if (propertyTypeFilter) params.append("propertyType", propertyTypeFilter);
      
      const response = await fetch(`/api/leads/export?${params.toString()}`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error("Export failed");
      }
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.style.display = "none";
      a.href = url;
      a.download = "leads.csv";
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    },
    onSuccess: () => {
      toast({
        title: "Export completed",
        description: "CSV file has been downloaded.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Export failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.type !== "text/csv" && !file.name.endsWith(".csv")) {
      toast({
        title: "Invalid file type",
        description: "Please select a CSV file.",
        variant: "destructive",
      });
      return;
    }

    Papa.parse(file, {
      header: true,
      complete: (results) => {
        const leads = results.data
          .filter((row: any) => row.firstName && row.lastName && row.email && row.propertyType)
          .map((row: any) => ({
            firstName: row.firstName,
            lastName: row.lastName,
            email: row.email,
            phone: row.phone || null,
            propertyType: row.propertyType,
            bhk: row.bhk || null,
            minBudget: row.minBudget || null,
            maxBudget: row.maxBudget || null,
            preferredLocation: row.preferredLocation || null,
            notes: row.notes || null,
            status: row.status || "active",
          }));

        if (leads.length === 0) {
          toast({
            title: "No valid data found",
            description: "Please ensure your CSV has the required fields: firstName, lastName, email, propertyType.",
            variant: "destructive",
          });
          return;
        }

        importMutation.mutate(leads);
      },
      error: (error) => {
        toast({
          title: "File parsing error",
          description: error.message,
          variant: "destructive",
        });
      },
    });

    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const downloadSampleTemplate = () => {
    const sampleData = [
      {
        firstName: "John",
        lastName: "Doe",
        email: "john.doe@example.com",
        phone: "+1234567890",
        propertyType: "residential",
        bhk: "3",
        minBudget: "300000",
        maxBudget: "500000",
        preferredLocation: "Downtown",
        notes: "Looking for a family home",
        status: "active",
      },
    ];

    const csv = Papa.unparse(sampleData);
    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.style.display = "none";
    a.href = url;
    a.download = "sample-leads-template.csv";
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  };

  return (
    <div className="min-h-screen bg-background flex">
      <Sidebar />
      
      <div className="flex-1 ml-64">
        {/* Header */}
        <header className="bg-card border-b border-border px-6 py-4">
          <div>
            <h1 className="text-xl font-semibold text-card-foreground" data-testid="page-title">
              Import & Export
            </h1>
            <p className="text-sm text-muted-foreground">Manage your lead data with CSV import and export functionality</p>
          </div>
        </header>

        {/* Main Content */}
        <main className="p-6 space-y-6 max-w-4xl">
          {/* Import Section */}
          <Card>
            <CardHeader>
              <div className="flex items-center">
                <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center mr-4">
                  <Upload className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <CardTitle>Import Leads</CardTitle>
                  <p className="text-sm text-muted-foreground">Upload a CSV file to import multiple leads at once</p>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div 
                className="border-2 border-dashed border-border rounded-lg p-8 text-center cursor-pointer hover:bg-accent/50 transition-colors"
                onClick={() => fileInputRef.current?.click()}
                data-testid="file-drop-zone"
              >
                <div className="w-12 h-12 bg-muted rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Upload className="h-6 w-6 text-muted-foreground" />
                </div>
                <p className="text-sm font-medium text-card-foreground mb-2">Drop your CSV file here, or click to browse</p>
                <p className="text-xs text-muted-foreground mb-4">Supports CSV files up to 10MB</p>
                <Button 
                  type="button"
                  disabled={importMutation.isPending}
                  data-testid="button-choose-file"
                >
                  {importMutation.isPending ? "Processing..." : "Choose File"}
                </Button>
                <input 
                  ref={fileInputRef}
                  type="file" 
                  accept=".csv" 
                  className="hidden" 
                  onChange={handleFileUpload}
                  data-testid="file-input"
                />
              </div>
              
              <div className="flex items-center justify-between">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={downloadSampleTemplate}
                  data-testid="button-download-template"
                >
                  <Download className="mr-2 h-4 w-4" />
                  Download Sample Template
                </Button>
                <div className="text-xs text-muted-foreground">
                  Required fields: firstName, lastName, email, propertyType
                </div>
              </div>

              {/* Import Results */}
              {importResults && (
                <div className="mt-4 p-4 border border-border rounded-lg" data-testid="import-results">
                  <div className="flex items-center mb-2">
                    {importResults.errors.length === 0 ? (
                      <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                    ) : (
                      <AlertCircle className="h-5 w-5 text-yellow-600 mr-2" />
                    )}
                    <h3 className="font-medium">Import Results</h3>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">
                    {importResults.total} records processed, {importResults.successful} successful, {importResults.errors.length} errors
                  </p>
                  {importResults.errors.length > 0 && (
                    <details className="text-xs">
                      <summary className="cursor-pointer text-destructive">View Errors</summary>
                      <ul className="mt-2 space-y-1">
                        {importResults.errors.map((error, index) => (
                          <li key={index} className="text-destructive">
                            Row {error.row}: {error.message}
                          </li>
                        ))}
                      </ul>
                    </details>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Export Section */}
          <Card>
            <CardHeader>
              <div className="flex items-center">
                <div className="w-10 h-10 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center mr-4">
                  <Download className="h-5 w-5 text-green-600 dark:text-green-400" />
                </div>
                <div>
                  <CardTitle>Export Leads</CardTitle>
                  <p className="text-sm text-muted-foreground">Download your leads data as a CSV file</p>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-card-foreground mb-2">Date Range</label>
                  <Select value={dateRange} onValueChange={setDateRange}>
                    <SelectTrigger data-testid="select-date-range">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All time</SelectItem>
                      <SelectItem value="30">Last 30 days</SelectItem>
                      <SelectItem value="90">Last 90 days</SelectItem>
                      <SelectItem value="365">This year</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-card-foreground mb-2">Status Filter</label>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger data-testid="select-export-status">
                      <SelectValue placeholder="All statuses" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All statuses</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="follow_up">Follow-up</SelectItem>
                      <SelectItem value="converted">Converted</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-card-foreground mb-2">Property Type</label>
                  <Select value={propertyTypeFilter} onValueChange={setPropertyTypeFilter}>
                    <SelectTrigger data-testid="select-export-property-type">
                      <SelectValue placeholder="All types" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All types</SelectItem>
                      <SelectItem value="residential">Residential</SelectItem>
                      <SelectItem value="commercial">Commercial</SelectItem>
                      <SelectItem value="land">Land</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="flex items-center justify-between pt-4">
                <div className="text-sm text-muted-foreground">
                  Export filtered leads to CSV format
                </div>
                <Button 
                  onClick={() => exportMutation.mutate()}
                  disabled={exportMutation.isPending}
                  data-testid="button-export"
                >
                  <Download className="mr-2 h-4 w-4" />
                  {exportMutation.isPending ? "Exporting..." : "Export CSV"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
